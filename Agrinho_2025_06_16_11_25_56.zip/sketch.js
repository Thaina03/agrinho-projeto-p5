let drone;

let trees = [];

let gameOver = false;

let startTime;

let duration = 30000; // 30 segundos

function setup() {

  createCanvas(600, 400);

  drone = createVector(50, height / 2);

  startTime = millis();

}

function draw() {

  background(135, 206, 235); // céu azul

  if (!gameOver) {

    // Desenhar drone

    fill(255, 0, 0);

    rect(drone.x, drone.y, 40, 20);

    // Controle drone

    if (keyIsDown(UP_ARROW)) drone.y -= 5;

    if (keyIsDown(DOWN_ARROW)) drone.y += 5;

    if (keyIsDown(LEFT_ARROW)) drone.x -= 5;

    if (keyIsDown(RIGHT_ARROW)) drone.x += 5;

    drone.x = constrain(drone.x, 0, width - 40);

    drone.y = constrain(drone.y, 0, height - 20);

    // Criar árvores aleatórias

    if (frameCount % 40 === 0) {

      let treeY = random(20, height - 40);

      trees.push(createVector(width, treeY));

    }

    // Mostrar e mover árvores

    fill(34, 139, 34);

    for (let i = trees.length - 1; i >= 0; i--) {

      trees[i].x -= 6;

      rect(trees[i].x, trees[i].y, 20, 40);

      // Checar colisão

      if (

        drone.x < trees[i].x + 20 &&

        drone.x + 40 > trees[i].x &&

        drone.y < trees[i].y + 40 &&

        drone.y + 20 > trees[i].y

      ) {

        gameOver = true;

      }

      if (trees[i].x < -20) {

        trees.splice(i, 1);

      }

    }

    // Mostrar tempo restante

    let elapsed = millis() - startTime;

    let timeLeft = max(0, duration - elapsed);

    fill(0);

    textSize(20);

    text("Tempo: " + floor(timeLeft / 1000), 10, 30);

    if (timeLeft <= 0) {

      gameOver = true;

    }

  } else {

    // Tela final

    background(0, 150, 0);

    fill(255);

    textSize(30);

    textAlign(CENTER, CENTER);

    if (millis() - startTime >= duration) {

      text("Missão concluída! Parabéns!", width / 2, height / 2 - 20);

    } else {

      text("Você bateu na árvore! Game Over!", width / 2, height / 2 - 20);

    }

    let score = floor(min(duration, millis() - startTime) / 1000);

    text("Tempo voado: " + score + "s", width / 2, height / 2 + 20);

  }

}